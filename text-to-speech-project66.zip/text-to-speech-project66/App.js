import React, { Component } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  Alert
} from 'react-native';
import * as Speech from 'expo-speech';
import Header from './components/Header';

export default class App extends Component {
  constructor() {
    super();
    this.state = {
      text: '',
    };
  }

  speak = () => {
    var thingToSay = this.state.text;
    Speech.speak(thingToSay);
  }

  render() {
    return (
      <View style={{ backgroundColor: 'cornsilk' }}>
        <View>
          <Header />

          <Image
            style={styles.imagestyle}
            source={{
              uri: 'https://miro.medium.com/max/700/0*PIm4S-fLsefifYAg.jpeg',
            }}
          />

          <TextInput
            style={styles.inputBox}
            onChangeText={(text) => {
              this.setState({ text: text });
            }}
          />
        </View>

        <View>
          <TouchableOpacity 
            style={[styles.buttonStyle]}
            onPress={()=>{
              this.state.text != '' 
              ? this.speak()
              : alert("please write some text")
            }}>
           <Text style={[styles.txtStyle]}>Hear Speech</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  imagestyle: {
    alignSelf: 'center',
    marginTop: 20,
    width: 300,
    height: 150,
    borderRadius: 20,
    marginBottom: 25,
  },

  inputBox: {
    borderColor: 'black',
    borderWidth: 5,
    paddingTop: 20,
    fontSize: 20,
    fontFamily: 'Arial',
  },

  buttonStyle: {
    backgroundColor: "darkblue",
    width: 150,
    height: 65,
    alignSelf: 'center',
    paddingTop: 23,
    paddingBottom: 20,
    textAlign: 'center',
    marginTop: 30,
    borderRadius: 20
  },

  txtStyle: {
    color: 'cornsilk',
    fontFamily: 'Arial',
    fontSize: 20,
    fontStyle: 'bold',
  }
});
